package projekat;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;


//Panel je klasa za crtanje poligona

public class PolygonPanel extends JPanel {
    //Lista poligona da bi ih moglo biti vise od jednog
    private List<PolygonPoints> _polygons;
    //Zastavica koja govori da je kursor misa blizu pocetne tacke poligona koji se trenutno crta
    private boolean _snap;
    //Zastavica koja obelezava da je ovo prvo iscrtavanje ekrana, koristi se samo jednom
    private boolean _first;

    public PolygonPanel() {
        _polygons = new ArrayList<>();
        //Podize se zastavica za prvo iscrtavanje ekrana
        _first=true;
        //Podesavanje boje pozadine panela
        setBackground(Color.WHITE);
        //Dodavanje event handlera za mis, odnosno
        //metode koje reaguju kada se mis pomeri
        setListeners();
    }

    private void setListeners() {
        
        addMouseMotionListener(new MouseAdapter() {
            //Metoda za reagovanje na pomeranje misa
            @Override
            public void mouseMoved(MouseEvent e) {
                super.mouseMoved(e);
                //Proveravamo da li uopste imamo neki poligon
                if (!_polygons.isEmpty()) {
                    //Ne moze da pocne novi, ako neki nije zavrsen)
                    PolygonPoints lastPolygon = _polygons.get(_polygons.size() - 1);
                    //Kad nije zatvoren
                    if (!lastPolygon.isClosed()) {
                        //Kopiranje proslu vrednost zastavice u privremenu promenljivu
                        boolean lastSnap = _snap;
                        //Porveravanje da li se kursor (e.getPoint) nalazi u radijusu od 20px u odnosu
                        //na prvu tacku i postavi zastavicu ako se nalazi, u suprotnom, skini je
                        _snap = lastPolygon.getFirstPoint().distance(e.getPoint()) < 20;
                        //Ako se zastavica promenila, iscrtaj opet ekran
                        if (lastSnap != _snap) {
                            //Metoda za ponovo iscrtavanje ekrana, definisana u klasi JPanel
                            repaint();
                        }
                    }
                }
            }
        });

        //Event handler za klik misa
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);
                //Switch-case u zavisnosti koje je dugme kliknuto
                switch (e.getButton()) {
                    //Ako je levi klik
                    case MouseEvent.BUTTON1:
                        //Pozivanje metode handleLeftClick (definisana je u ovoj klasi, dole)
                        handleLeftClick(e.getPoint());
                        break;
                    case MouseEvent.BUTTON3:
                        //Pozivanje metodw handleRightClick (definisana je u ovoj klasi, dole)
                        handleRightClick();
                        break;
                }

            }
        });
    }

    //Metoda ako se desni klik mise izabre, brise sve sa ekrana
    private void handleRightClick() {
        //Brisanje svega (Definisana u klasi PolygonPoints)
        _polygons.clear();
        //Crtanje ekrana, praznog
        repaint();
    }

    //Metoda ako se levi klik mise izabre, zatvara poligon ili kreira novi
    private void handleLeftClick(Point p) {
        //Ako je zastavica podignuta, sigurno postoji otvoren poligon
        //Tada ga zatvori i spusti zastavicu
        if (_snap) {
            getOpenPolygon().close();
            _snap = false;
        } else {
            //Ako ne, dodaj tacku ili kreiraj novi i dodaj tacku
        	//Metoda getOpenPolygon() je kreirana u ovoj klasi, dole
            getOpenPolygon().add(p);
        }
        //Nacrtaj ekran opet
        repaint();
    }

    //Metoda koja vraca otvoreni poligon, na koji treba da se dodaju tacke
    private PolygonPoints getOpenPolygon() {
        //Ako nema otvorenih poligona, pravi nov i vraca ga
        if (_polygons.isEmpty() || _polygons.get(_polygons.size() - 1).isClosed()) {
            PolygonPoints newPolygon = new PolygonPoints();
            _polygons.add(newPolygon);
            return newPolygon;
        }
        //Ako postoji otvoreni poligon, vrati njega
        return _polygons.get(_polygons.size() - 1);
    }


    //Ova metoda je definisana u superklasi JPanel 
    //Kada se zove metoda repaint(), ona implicitno pozove i ovu metodu
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        //Kad je prvo iscrtavanje
        if (_first){
            //Graficki objekat pretvaramo u Java2D objekat da bismo mogli da crtamo
            Graphics2D g2d = (Graphics2D) g;
            //Ovo je prazan string jer Java2D treba da ucita fontove
            g.drawString("Nacrtaj poligon",300,246);
            _first = false;
        }
        //Provera da li ima poligona za crtanje
        if (!_polygons.isEmpty()){
        	//Graficki objekat pretvaramo u Java2D objekat da bismo mogli da crtamo
            Graphics2D g2d = (Graphics2D) g;
            //Za fine linije
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            //Provera da li poslednji zatvoren
            PolygonPoints lastPolygon = _polygons.get(_polygons.size()-1);
            if (!lastPolygon.isClosed()){
                //Ako je otvoren, nacrtati njegove tacke
                for (int i = 0; i < lastPolygon.getPoints().size(); i++){
                    //Ako je ukljucena snap zastavica, oboji prvi cvor u razlicitu boju od ostalih
                    if (i==0 && _snap) {
                        g2d.setColor(Color.CYAN);
                    } else {
                        g2d.setColor(Color.MAGENTA);
                    }
                    //Crtanje kruga precnika 5, sa centrom u koordinatama tacaka poligona
                    g2d.fillOval((int) lastPolygon.getPoints().get(i).getX(),
                            (int) lastPolygon.getPoints().get(i).getY(), 5, 5);
                }
            }
            //Crtanje ostalih koji su zatvoreni i racunanje njihovih povrsina
            for (PolygonPoints pPoints : _polygons){
                //Ako je zatvoren
                if (pPoints.isClosed()){
                    //Boja poligona
                    g2d.setColor(Color.CYAN);
                    //Crtanje poligona
                    g2d.fillPolygon(pPoints.toPolygon());
                    //Boja fonta
                    g2d.setColor(Color.MAGENTA);
                    //Pravougaonik oko trenutnog poligona, zbog vadjenja centra poligona
                    Rectangle r = pPoints.toPolygon().getBounds();
                    //Stampanje povrsine u centru
                    g2d.drawString(String.valueOf(pPoints.calculateArea()), (int) r.getCenterX(), (int) r.getCenterY());
                }
            }
        }

    }
}
