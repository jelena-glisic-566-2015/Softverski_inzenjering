package projekat;

import javax.swing.*;
import java.awt.*;

public class App{

    
    public static void main(String[] args) {

        //Podizanje grafickih aplikacija
        EventQueue.invokeLater(() -> {
            //Objekat prozora
            JFrame frame = new JFrame();
            //Panel za crtanje
            JPanel panel = new PolygonPanel();
            // Dodavanje panela u prozor
            frame.add(panel);
            //Velicina prozora 640x480 piksela
            frame.setSize(640, 480);
            //Prikazati prozor
            frame.setVisible(true);
            //Naslov prozora
            frame.setTitle("Levi klik - crtanje cvorova, desni klik - brisanje svega");
            //Kada se klikne na dugme za izlaz, aplikacija se gasi
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            //Nije dozvoljeno menjanje velicine prozora rucno
            frame.setResizable(false);
        });
    }

}
