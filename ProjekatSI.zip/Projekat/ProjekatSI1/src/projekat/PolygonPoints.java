package projekat;

//Sruktura koja cuva X, Y koordinatu neke tacke u ravni

import java.awt.*;

import java.util.ArrayList;
import java.util.List;

public class PolygonPoints {
    private List<Point> _points;
    private boolean _closed;

    public PolygonPoints() {
        _points = new ArrayList<>();
    }
    
    //Dodavanje pocetne tacke
    public PolygonPoints(Point p){
        this();
        _points.add(p);
    }
    
    //Dodavanje nove tacke
    public void add(Point p){
        _points.add(p);
    }

    //Vracanje liste svih tacaka
    public List<Point> getPoints(){
        return _points;
    }
    
    //Vracanje prve tacke
    public Point getFirstPoint(){
        if (_points.isEmpty()){
            return null;
        } else {
            return _points.get(0);
        }
    }

    //Zatvoranje poligona
    public void close(){
        _closed = true;
    }
    
    //Vracanje da li je poligon zatvoren
    public boolean isClosed(){
        return _closed;
    }
    
    //Brisanje poligona
    public void clear() {
        _points.clear();
    }

    //Vracanje da li je lista tacaka prazna
    public boolean isEmpty() {
        return _points.isEmpty();
    }

    //Racuna povrsinu poligona koristeci Algoritam pertle
    //https://sr.wikipedia.org/wiki/Formula_pertle

    //Formula glasi:
    //       1 | n-1                        n-1                     |
    //  A =  - |  ∑ (x(i)y(i+1) + x(n)y(1) - ∑ (x(i+1)y(i)-x(1)y(n) |
    //       2 | i=1                        i=1                     |
    public double calculateArea() {
        //ako poligon nije nacrtan vrati da je povrsina nula
        if (isEmpty()) {
            return 0d;
        }
        
        double sum1 = 0;
        double sum2 = 0;

        //Sume po formuli pertle
        for (int i = 0; i < _points.size() - 1; i++){
            sum1 += _points.get(i).getX() * _points.get(i+1).getY();
            sum2 += _points.get(i).getY() * _points.get(i+1).getX();
        }

        //x1 - prvi cvor, xn - poslednji cvor X koordinate
        //y1 - prvi cvor, yn - poslednji cori Y koordinate
        double x1 = _points.get(0).getX();
        double y1 = _points.get(0).getY();
        double xn = _points.get(_points.size() - 1).getX();
        double yn = _points.get(_points.size() - 1).getY();

        //Formula
        return 0.5 * Math.abs(sum1 + xn * y1 - sum2 - x1 * yn);
    }

    //Pretvaranje ove strukture podataka u Javinu klasu koja ce da se crta na ekranu funkcijom  
    // fillPolygon
    public Polygon toPolygon(){
        
    	Polygon p = new Polygon();
        //Dodavanje svake tacke strukture u Javin poligon
        for (Point point : _points){
            //Poligon ima celobrojne vrednosti koordinata pa zato int
            p.addPoint((int) point.getX(), (int) point.getY());
        }
        return p;
    }
}
